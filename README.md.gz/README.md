# eunseo
✔ 스터디 과목 : NODE <br/>
✔스터디 팀 : NODE 1
